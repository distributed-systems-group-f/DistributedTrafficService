--
-- PostgreSQL database dump
--

\restrict 30TmP1E9fMXhd0jYPGknNEyhKmidskyaHLB74l3PRXkhcenIBYfyrgQNeAL9llF

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY region_uk.reservations DROP CONSTRAINT IF EXISTS reservations_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY region_ireland.reservations DROP CONSTRAINT IF EXISTS reservations_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY region_france.reservations DROP CONSTRAINT IF EXISTS reservations_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.segment_reservations DROP CONSTRAINT IF EXISTS segment_reservations_booking_id_fkey;
DROP INDEX IF EXISTS public.idx_segment_reservations_booking_status;
DROP INDEX IF EXISTS public.idx_notifications_user_sent_at;
DROP INDEX IF EXISTS public.idx_bookings_plate_status_departure;
DROP INDEX IF EXISTS public.idx_bookings_driver_created;
DROP INDEX IF EXISTS auth.idx_auth_users_plate_number;
DROP INDEX IF EXISTS analytics.idx_analytics_events_type_created;
ALTER TABLE IF EXISTS ONLY region_uk.road_segments DROP CONSTRAINT IF EXISTS road_segments_pkey;
ALTER TABLE IF EXISTS ONLY region_uk.reservations DROP CONSTRAINT IF EXISTS reservations_pkey;
ALTER TABLE IF EXISTS ONLY region_ireland.road_segments DROP CONSTRAINT IF EXISTS road_segments_pkey;
ALTER TABLE IF EXISTS ONLY region_ireland.reservations DROP CONSTRAINT IF EXISTS reservations_pkey;
ALTER TABLE IF EXISTS ONLY region_france.road_segments DROP CONSTRAINT IF EXISTS road_segments_pkey;
ALTER TABLE IF EXISTS ONLY region_france.reservations DROP CONSTRAINT IF EXISTS reservations_pkey;
ALTER TABLE IF EXISTS ONLY public.segment_reservations DROP CONSTRAINT IF EXISTS segment_reservations_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.bookings DROP CONSTRAINT IF EXISTS bookings_pkey;
ALTER TABLE IF EXISTS ONLY auth.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY auth.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY analytics.booking_events DROP CONSTRAINT IF EXISTS booking_events_pkey;
DROP TABLE IF EXISTS region_uk.road_segments;
DROP TABLE IF EXISTS region_uk.reservations;
DROP TABLE IF EXISTS region_ireland.road_segments;
DROP TABLE IF EXISTS region_ireland.reservations;
DROP TABLE IF EXISTS region_france.road_segments;
DROP TABLE IF EXISTS region_france.reservations;
DROP TABLE IF EXISTS public.segment_reservations;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.bookings;
DROP TABLE IF EXISTS auth.users;
DROP TABLE IF EXISTS analytics.booking_events;
DROP EXTENSION IF EXISTS pgcrypto;
DROP SCHEMA IF EXISTS region_uk;
DROP SCHEMA IF EXISTS region_ireland;
DROP SCHEMA IF EXISTS region_france;
DROP SCHEMA IF EXISTS auth;
DROP SCHEMA IF EXISTS analytics;
--
-- Name: analytics; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA analytics;


--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: region_france; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA region_france;


--
-- Name: region_ireland; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA region_ireland;


--
-- Name: region_uk; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA region_uk;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: booking_events; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.booking_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    region character varying(50),
    segment_id uuid,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'driver'::character varying NOT NULL,
    plate_number character varying(20),
    region character varying(50),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    driver_id uuid NOT NULL,
    origin_lat double precision,
    origin_lng double precision,
    destination_lat double precision,
    destination_lng double precision,
    departure_time timestamp without time zone NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    estimated_duration_minutes integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    plate_number character varying(20)
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    booking_id uuid,
    event_type character varying(50) NOT NULL,
    channel character varying(20) NOT NULL,
    message text NOT NULL,
    sent_at timestamp without time zone DEFAULT now()
);


--
-- Name: segment_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.segment_reservations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid,
    segment_id uuid NOT NULL,
    region character varying(50) NOT NULL,
    time_slot_start timestamp without time zone NOT NULL,
    time_slot_end timestamp without time zone NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: reservations; Type: TABLE; Schema: region_france; Owner: -
--

CREATE TABLE region_france.reservations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid NOT NULL,
    segment_id uuid,
    driver_id uuid NOT NULL,
    time_slot_start timestamp without time zone NOT NULL,
    time_slot_end timestamp without time zone NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: road_segments; Type: TABLE; Schema: region_france; Owner: -
--

CREATE TABLE region_france.road_segments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    start_point_lat double precision,
    start_point_lng double precision,
    end_point_lat double precision,
    end_point_lng double precision,
    max_capacity_per_slot integer DEFAULT 100 NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: reservations; Type: TABLE; Schema: region_ireland; Owner: -
--

CREATE TABLE region_ireland.reservations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid NOT NULL,
    segment_id uuid,
    driver_id uuid NOT NULL,
    time_slot_start timestamp without time zone NOT NULL,
    time_slot_end timestamp without time zone NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: road_segments; Type: TABLE; Schema: region_ireland; Owner: -
--

CREATE TABLE region_ireland.road_segments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    start_point_lat double precision,
    start_point_lng double precision,
    end_point_lat double precision,
    end_point_lng double precision,
    max_capacity_per_slot integer DEFAULT 100 NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: reservations; Type: TABLE; Schema: region_uk; Owner: -
--

CREATE TABLE region_uk.reservations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid NOT NULL,
    segment_id uuid,
    driver_id uuid NOT NULL,
    time_slot_start timestamp without time zone NOT NULL,
    time_slot_end timestamp without time zone NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: road_segments; Type: TABLE; Schema: region_uk; Owner: -
--

CREATE TABLE region_uk.road_segments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    start_point_lat double precision,
    start_point_lng double precision,
    end_point_lat double precision,
    end_point_lng double precision,
    max_capacity_per_slot integer DEFAULT 100 NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Data for Name: booking_events; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.booking_events (id, booking_id, driver_id, event_type, region, segment_id, created_at) FROM stdin;
70e5d7be-4211-4b40-8d6b-67be842cbb45	7688b4c8-c41c-4966-9a7c-c9d4c7bfe087	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	unknown	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-03-30 12:32:16.00336
b437500a-f699-4c65-aa65-6f2c5df85764	289f7eac-b04e-4665-9438-ac31c1cedfd3	aa8d041e-41a6-410b-96d5-7f2a3682c993	booking.failed	\N	\N	2026-04-04 08:50:25.776885
3d26af12-fc91-46d6-a572-0cc8dbf390e9	d047b1c9-dcef-4b72-8d96-7f83c0257db5	92fee392-4945-4183-b04c-f50c7e876988	booking.failed	\N	\N	2026-04-04 08:50:55.984889
0a7bdc41-9db5-4cd9-926b-cf0427c86eff	5b8c7e27-34ee-4674-a041-1f41f57ae066	9e65c5b8-f994-4f0b-b96f-260448751002	booking.failed	\N	\N	2026-04-04 08:51:13.493416
3bd134c2-2c21-4c10-a3fe-47237eacd949	928c7ac6-df7e-4c6c-8924-9ec8472ded15	8db41428-a58c-40e1-afbe-716906218c8c	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 08:51:53.142975
7dbd49ca-24ec-4b23-81c1-cb502b93f010	2a5c1d0f-a7a9-450e-bded-29846ec08b30	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 08:52:36.383529
379c52d5-2117-4317-b84e-f94e7cf4ffa9	fda32288-95af-41bf-8c03-56c9fd6c09c4	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 08:52:37.233703
f8372045-6201-466e-ba94-3e02a5231224	e93d455f-00d3-40dd-809c-305c90488a3c	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 08:52:37.2425
501e2965-8c7d-4445-b841-1b102ebf7403	a36c30f9-2199-43f0-b658-907779cff93c	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 08:52:37.248699
71e4aa87-54f3-45c0-9ded-e921dc185e84	03476c7f-fa64-4081-bc32-5fb9c85aab51	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 08:52:38.059415
8aa27c65-7cc1-4a89-b674-44e0624dd1b6	03476c7f-fa64-4081-bc32-5fb9c85aab51	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_UK	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	2026-04-04 08:52:38.061143
07124a36-7d39-46b5-96a4-ea8309cd53de	19b0fada-f680-4168-82ca-61adf041026f	27b8e42a-e893-441b-a466-cc7d9a90f633	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 08:57:07.684028
6f520af9-e4d6-4474-bc30-e4af5b768851	db655139-a079-4beb-a08a-0cd9f8cf29db	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 08:59:09.49517
e17bb1f5-44f8-4bf3-b176-b4147cb138fc	7688b4c8-c41c-4966-9a7c-c9d4c7bfe087	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.cancelled	\N	\N	2026-04-04 08:59:15.979079
2fe75676-a9af-4ecd-891f-4e1e5637fa1e	db655139-a079-4beb-a08a-0cd9f8cf29db	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.cancelled	\N	\N	2026-04-04 09:00:06.996091
ee2af24c-e7d5-4eb1-9daa-2294e4c8b4dc	0b8318d5-1312-4f08-9ced-07107c089b07	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.confirmed	EU_WEST_FRANCE	0dfcd849-f0b8-5213-b721-44b067f63dd3	2026-04-04 09:00:19.112648
cc61914a-a127-4545-aa78-8eb3c58e2080	0b8318d5-1312-4f08-9ced-07107c089b07	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 09:00:19.114096
de38bc2f-37eb-442b-9d0d-421dc706f5f8	9bd5b11e-30d0-412d-b3ec-d567fb0dd769	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 09:10:01.185615
b05c2152-b2bd-403a-baad-e5e19aa4d395	351226b2-e18c-4e58-b68a-bfbafbebfb34	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.failed	\N	\N	2026-04-04 09:10:02.036538
4a725965-afe5-4e12-bcfb-95ced2639bda	51b6d9c5-f71f-4063-a564-d14e7c316bb5	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 09:10:02.040465
11517e23-eeb5-4857-a2fe-eb403d949239	1968a902-b369-4bf0-912b-04fc16786cec	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 09:10:02.049473
bf8574d1-cdc2-4695-a0f5-6f117057ca65	7e475cb7-c49d-43e3-8836-bb80d1a5ed64	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 09:10:02.869768
2a7eb2fe-bd2b-4e8f-8635-3b27d1d00bfa	7e475cb7-c49d-43e3-8836-bb80d1a5ed64	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_UK	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	2026-04-04 09:10:02.871497
d5777a99-04eb-440e-adf5-df93fd73e2aa	d51f2799-249b-4872-9415-de7a25c79b3c	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 09:22:53.496578
9a705684-5416-4892-9acc-b2913801a6a8	42f5def3-c5fc-4b12-891b-1494c5d2eba1	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_IRELAND	c8476fce-4136-5a82-a985-be50e80de41d	2026-04-04 09:22:54.316269
adf5c870-3bab-4734-8d8f-a80e18edfd62	42f5def3-c5fc-4b12-891b-1494c5d2eba1	e83817d3-04f0-4469-833e-f13a5b8d9d2f	booking.confirmed	EU_WEST_UK	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	2026-04-04 09:22:54.318755
720970ec-91a2-42b4-b605-2b373179808d	8cf09e83-ea08-4225-8f15-ebbdf364fe3a	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.confirmed	EU_WEST_IRELAND	e71ba8fb-58a5-41f3-9383-7159375d2f6f	2026-04-04 09:30:39.359203
f1df0af1-0bc8-4830-a865-c49e81c2ce81	8cf09e83-ea08-4225-8f15-ebbdf364fe3a	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.confirmed	EU_WEST_UK	9aedc4fe-365e-4f44-97a9-46449d50750c	2026-04-04 09:30:39.36149
803df3bc-ba71-4f05-b4a3-51a5f72668c7	2d417377-0315-4df2-b7d1-f9ea8e3c98c0	824272c8-6988-4174-8a6c-6e6b1aff23b2	booking.confirmed	EU_WEST_UK	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	2026-04-04 09:31:38.106896
96277641-e916-4594-904f-2b4bd68403af	9a3af9eb-5401-473b-9182-297acc0963c7	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.confirmed	EU_WEST_IRELAND	e71ba8fb-58a5-41f3-9383-7159375d2f6f	2026-04-04 09:35:07.000623
f4af66b6-6265-4d89-bbbd-edecdcfd8d83	9a3af9eb-5401-473b-9182-297acc0963c7	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.confirmed	EU_WEST_UK	9aedc4fe-365e-4f44-97a9-46449d50750c	2026-04-04 09:35:07.002667
75e51798-e590-4f25-a25a-84780eba2cc6	d9690f73-6749-425f-8c7b-09fd107c3371	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	booking.confirmed	EU_WEST_IRELAND	5bd68e8c-963d-4b1f-97cf-6f443ec457cd	2026-04-04 09:49:01.814327
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (id, email, password_hash, role, plate_number, region, created_at) FROM stdin;
824272c8-6988-4174-8a6c-6e6b1aff23b2	agent@test.com	$2b$12$FX43g4rE8BJpB95V66YPIeP35OiMxJUIkMGnbWubp1jYhAqA8Msi.	enforcement_agent	\N	EU_WEST_IRELAND	2026-03-30 12:31:45.693216
7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	driver@test.com	$2b$12$b.M0xxBIl.KcTS6./n9FReDf3Si5ngudxRYYQRz9G307NpQZ7nGx2	driver	241-D-12345	EU_WEST_IRELAND	2026-03-30 12:32:11.442744
cf8d1152-50f4-41a6-9208-960d7446a970	admin_1775292624@test.com	$2b$12$i23q7ucp7uOK8nko8rcFle18tFHDEhSGYQuGqHyRKWMgwklCMNHuC	admin	\N	EU_WEST_IRELAND	2026-04-04 08:50:24.532015
aa8d041e-41a6-410b-96d5-7f2a3682c993	driver_1775292624@test.com	$2b$12$mc26HVKoYk5ZLtFR6wWQeeDhWkrH0eJKgdr0b1TeCPzf6C2B8Qqz2	driver	TEST-1775292624	EU_WEST_IRELAND	2026-04-04 08:50:25.327686
43c467f1-0fac-49ae-ba5e-6753454517f8	admin_1775292654@test.com	$2b$12$xTKAtMpI0pp0sFA0ztvwSeljMCWfyYZotT4DKE.WVVGuszu6UNY16	admin	\N	EU_WEST_IRELAND	2026-04-04 08:50:54.783249
92fee392-4945-4183-b04c-f50c7e876988	driver_1775292654@test.com	$2b$12$4RlZh/vmXjOx684sLtCOCuTBaipCxy8yPEJSg8LRMMMcIHI97Y.wO	driver	TEST-1775292654	EU_WEST_IRELAND	2026-04-04 08:50:55.566039
9e65c5b8-f994-4f0b-b96f-260448751002	driver_dbg_1775292672@test.com	$2b$12$ggleVFwjl8YKboHl43h.uOeJf/eJB6QdqUz3kAH50hJUkKlEdE7EC	driver	DBG-1775292672	EU_WEST_IRELAND	2026-04-04 08:51:13.063424
092bda7d-2a42-45b1-9f10-2a4183059e6b	admin_1775292711@test.com	$2b$12$yq0AyQccDDRz.Tw0Ga5p1OnD/oXxjzNxbLQwVmVDgdw6mzGhc4IcG	admin	\N	EU_WEST_IRELAND	2026-04-04 08:51:51.913428
8db41428-a58c-40e1-afbe-716906218c8c	driver_1775292711@test.com	$2b$12$Th32Op33UBzexl3dKCmP8u9vmsikWX9JUEngZI79rb1pzQhqk622S	driver	TEST-1775292711	EU_WEST_IRELAND	2026-04-04 08:51:52.70473
6f61e72f-2249-4a52-ae79-ea742ca9c7fd	driver_4b43770b@test.com	$2b$12$GahztgLCsWSdMrIvdOxADOcqwKyf98S.qLz0FMjKP1Hjr99CfpIu6	driver	FLOW-001	\N	2026-04-04 08:52:35.208496
e83817d3-04f0-4469-833e-f13a5b8d9d2f	testdriver@example.com	$2b$12$1Ng2ebiiuH0G4.bVoRFge.tJEZFac4NImsXtYUh2AHnJYu54hTWce	driver	TEST-001	EU_WEST_IRELAND	2026-04-04 08:52:35.980883
27b8e42a-e893-441b-a466-cc7d9a90f633	demo_driver_1775293026@test.com	$2b$12$i7GpgisWnvZJmovR5yzHxO8CoENmaN2xy4zTJwBmkZn7UVBWUGhpi	driver	DEMO-1775293026	EU_WEST_IRELAND	2026-04-04 08:57:07.240267
83edae84-7dcb-439e-a717-382578e8cdb1	demo_admin_1775293054@test.com	$2b$12$Xjkcm8asBtCFmPkkyJxOj.LJNb99c6Mkshm9uJ94u92zgNZBQrwJu	admin	\N	EU_WEST_IRELAND	2026-04-04 08:57:34.690288
8fc41f22-1e6e-49fe-8613-5f11cc1e2795	admin@test.com	$2b$12$Zit//C52CUH2IIalmS.T5.UICt0oYRgQurY.U8EUGJl.x6J6yFen.	admin	\N	EU_WEST_IRELAND	2026-04-04 09:01:20.572224
43627ff4-461f-4205-804a-51d365ef1808	driver_19374403@test.com	$2b$12$9.SGlOkQ3E6WnZeGB.ylw.G0EcQMgMvkdXDJFl8cICVaKHJcj8eE.	driver	FLOW-001	\N	2026-04-04 09:09:59.963856
6a4734e4-a5a6-4f2a-8986-37fbd1b4ebcd	driver_caa6f868@test.com	$2b$12$06uQRTOre/n0W.u48mTMnOhnR1L4q9kPLFe0dix77RLcd76qw7Doq	driver	FLOW-001	\N	2026-04-04 09:22:52.291366
7f3a421c-e123-4d9d-9b42-4a05d84c69cc	maptest@example.com	$2b$12$AaXrU7lfcr6aLI0bB4uINe4asGDFpEh1e7XJp66BKVm6jA/njpnOu	driver	MAP-001	\N	2026-04-04 09:44:20.171388
6730c7a0-4f60-4e66-9d8b-82a514b34132	partition_test_1775640218@test.com	$2b$12$que7HS6CIK0r/R.4i.1pWOKgmPTeVKHNQ484mQ7rW/AQNk19qfDuS	driver	PART-1775640218	\N	2026-04-08 09:23:39.190458
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookings (id, driver_id, origin_lat, origin_lng, destination_lat, destination_lng, departure_time, status, estimated_duration_minutes, created_at, updated_at, plate_number) FROM stdin;
9a3af9eb-5401-473b-9182-297acc0963c7	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	53.3498	-6.2603	52.4862	-1.8904	2026-04-04 10:00:00	CONFIRMED	209	2026-04-04 09:35:06.975958	2026-04-04 09:35:07.000955	ABCD-1234
289f7eac-b04e-4665-9438-ac31c1cedfd3	aa8d041e-41a6-410b-96d5-7f2a3682c993	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 09:50:25	REJECTED	60	2026-04-04 08:50:25.752731	2026-04-04 08:50:25.752734	TEST-1775292624
d047b1c9-dcef-4b72-8d96-7f83c0257db5	92fee392-4945-4183-b04c-f50c7e876988	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 09:50:55	REJECTED	60	2026-04-04 08:50:55.97412	2026-04-04 08:50:55.974122	TEST-1775292654
5b8c7e27-34ee-4674-a041-1f41f57ae066	9e65c5b8-f994-4f0b-b96f-260448751002	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 09:51:13	REJECTED	60	2026-04-04 08:51:13.483323	2026-04-04 08:51:13.483325	DBG-1775292672
928c7ac6-df7e-4c6c-8924-9ec8472ded15	8db41428-a58c-40e1-afbe-716906218c8c	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 09:51:53	CONFIRMED	60	2026-04-04 08:51:53.129535	2026-04-04 08:51:53.145411	TEST-1775292711
2a5c1d0f-a7a9-450e-bded-29846ec08b30	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 09:52:36.358087	CONFIRMED	60	2026-04-04 08:52:36.371154	2026-04-04 08:52:36.386163	TEST-001
fda32288-95af-41bf-8c03-56c9fd6c09c4	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 11:52:37.174637	CONFIRMED	60	2026-04-04 08:52:37.199032	2026-04-04 08:52:37.23607	TEST-001
e93d455f-00d3-40dd-809c-305c90488a3c	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 11:52:37.174637	CONFIRMED	60	2026-04-04 08:52:37.210833	2026-04-04 08:52:37.243875	TEST-001
a36c30f9-2199-43f0-b658-907779cff93c	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 11:52:37.174637	CONFIRMED	60	2026-04-04 08:52:37.233474	2026-04-04 08:52:37.250389	TEST-001
03476c7f-fa64-4081-bc32-5fb9c85aab51	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	52.4862	-1.8904	2026-04-04 10:52:38.033447	CONFIRMED	60	2026-04-04 08:52:38.047812	2026-04-04 08:52:38.060495	TEST-001
19b0fada-f680-4168-82ca-61adf041026f	27b8e42a-e893-441b-a466-cc7d9a90f633	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 09:57:07	CONFIRMED	60	2026-04-04 08:57:07.672962	2026-04-04 08:57:07.684598	DEMO-1775293026
7688b4c8-c41c-4966-9a7c-c9d4c7bfe087	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	53.3498	-6.2603	51.8969	-8.4863	2026-03-30 13:00:00	CANCELLED	60	2026-03-30 12:32:15.956084	2026-04-04 08:59:15.968152	\N
db655139-a079-4beb-a08a-0cd9f8cf29db	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	53.3498	-6.2603	51.8969	-8.4863	2026-04-04 09:00:00	CANCELLED	60	2026-04-04 08:59:09.483258	2026-04-04 09:00:06.983965	241-D-12345
0b8318d5-1312-4f08-9ced-07107c089b07	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	48.8566	2.3522	53.3498	-6.2603	2026-04-04 10:00:00	CONFIRMED	60	2026-04-04 09:00:19.099641	2026-04-04 09:00:19.114005	24-D-1234
9bd5b11e-30d0-412d-b3ec-d567fb0dd769	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 10:10:01.13401	CONFIRMED	60	2026-04-04 09:10:01.156248	2026-04-04 09:10:01.181684	TEST-001
351226b2-e18c-4e58-b68a-bfbafbebfb34	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 12:10:01.974461	REJECTED	60	2026-04-04 09:10:02.006191	2026-04-04 09:10:02.006192	TEST-001
51b6d9c5-f71f-4063-a564-d14e7c316bb5	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 12:10:01.974461	CONFIRMED	60	2026-04-04 09:10:02.006388	2026-04-04 09:10:02.042982	TEST-001
1968a902-b369-4bf0-912b-04fc16786cec	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 12:10:01.974461	CONFIRMED	60	2026-04-04 09:10:02.03064	2026-04-04 09:10:02.051525	TEST-001
7e475cb7-c49d-43e3-8836-bb80d1a5ed64	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	52.4862	-1.8904	2026-04-04 11:10:02.842704	CONFIRMED	60	2026-04-04 09:10:02.858333	2026-04-04 09:10:02.871454	TEST-001
d51f2799-249b-4872-9415-de7a25c79b3c	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	51.8985	-8.4756	2026-04-04 10:22:53.464238	CONFIRMED	60	2026-04-04 09:22:53.478037	2026-04-04 09:22:53.496388	TEST-001
42f5def3-c5fc-4b12-891b-1494c5d2eba1	e83817d3-04f0-4469-833e-f13a5b8d9d2f	53.3498	-6.2603	52.4862	-1.8904	2026-04-04 11:22:54.290568	CONFIRMED	60	2026-04-04 09:22:54.301597	2026-04-04 09:22:54.316927	TEST-001
ae75ada7-a573-45d4-93cb-11435c4f5e56	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	48.8566	2.3522	53.3498	-6.2603	2026-04-04 10:00:00	REJECTED	\N	2026-04-04 09:25:02.487811	2026-04-04 09:25:02.492803	241-D-12345
8cf09e83-ea08-4225-8f15-ebbdf364fe3a	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	53.3498	-6.2603	52.4862	-1.8904	2026-04-05 11:00:00	CONFIRMED	209	2026-04-04 09:30:39.335065	2026-04-04 09:30:39.360169	AB-1234-CD
2d417377-0315-4df2-b7d1-f9ea8e3c98c0	824272c8-6988-4174-8a6c-6e6b1aff23b2	51.5074	-0.1278	53.4808	-2.2426	2026-04-04 10:00:00	CONFIRMED	175	2026-04-04 09:31:38.094026	2026-04-04 09:31:38.109592	AB-1234
f9cd580f-3a20-4ce6-a574-acb70f83670f	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	48.8566	2.3522	53.3498	-6.2603	2026-04-04 10:00:00	REJECTED	\N	2026-04-04 09:35:48.961001	2026-04-04 09:35:48.963438	ABCD-12345
d9690f73-6749-425f-8c7b-09fd107c3371	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	53.3498	-6.2603	53.2707	-9.0568	2026-04-04 10:00:00	CONFIRMED	124	2026-04-04 09:49:01.75839	2026-04-04 09:49:01.797562	AB-1234-56
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, booking_id, event_type, channel, message, sent_at) FROM stdin;
34ed18d4-f8cb-4a2f-91b4-c2177380d9e4	aa8d041e-41a6-410b-96d5-7f2a3682c993	289f7eac-b04e-4665-9438-ac31c1cedfd3	booking.failed	push	Booking 289f7eac-b04e-4665-9438-ac31c1cedfd3 could not be confirmed. Please try again.	2026-04-04 08:50:25.776223
180535ca-0ab3-49b2-9156-794b74856018	aa8d041e-41a6-410b-96d5-7f2a3682c993	289f7eac-b04e-4665-9438-ac31c1cedfd3	booking.failed	email	Booking 289f7eac-b04e-4665-9438-ac31c1cedfd3 could not be confirmed. Please try again.	2026-04-04 08:50:25.77836
729a1bf2-a390-4e7a-8d76-b70e0895fb04	92fee392-4945-4183-b04c-f50c7e876988	d047b1c9-dcef-4b72-8d96-7f83c0257db5	booking.failed	push	Booking d047b1c9-dcef-4b72-8d96-7f83c0257db5 could not be confirmed. Please try again.	2026-04-04 08:50:55.98467
4f2d8353-8ccf-468a-b3ac-be35c2445bcc	92fee392-4945-4183-b04c-f50c7e876988	d047b1c9-dcef-4b72-8d96-7f83c0257db5	booking.failed	email	Booking d047b1c9-dcef-4b72-8d96-7f83c0257db5 could not be confirmed. Please try again.	2026-04-04 08:50:55.987069
60b25e4f-95cd-48d8-94a3-0819bad262df	9e65c5b8-f994-4f0b-b96f-260448751002	5b8c7e27-34ee-4674-a041-1f41f57ae066	booking.failed	push	Booking 5b8c7e27-34ee-4674-a041-1f41f57ae066 could not be confirmed. Please try again.	2026-04-04 08:51:13.493374
feb6e773-8ba5-432c-b32f-25c8d5bee9f9	9e65c5b8-f994-4f0b-b96f-260448751002	5b8c7e27-34ee-4674-a041-1f41f57ae066	booking.failed	email	Booking 5b8c7e27-34ee-4674-a041-1f41f57ae066 could not be confirmed. Please try again.	2026-04-04 08:51:13.496019
3fea2297-2686-43a2-b7be-3d5e73b94df5	8db41428-a58c-40e1-afbe-716906218c8c	928c7ac6-df7e-4c6c-8924-9ec8472ded15	booking.confirmed	push	Your booking 928c7ac6-df7e-4c6c-8924-9ec8472ded15 is confirmed.	2026-04-04 08:51:53.143001
4b079268-ad2c-42d0-937f-3797e5e08868	8db41428-a58c-40e1-afbe-716906218c8c	928c7ac6-df7e-4c6c-8924-9ec8472ded15	booking.confirmed	sms	Your booking 928c7ac6-df7e-4c6c-8924-9ec8472ded15 is confirmed.	2026-04-04 08:51:53.1448
4b3d8844-e8c0-4c93-b92b-3f75cdf47b51	8db41428-a58c-40e1-afbe-716906218c8c	928c7ac6-df7e-4c6c-8924-9ec8472ded15	booking.confirmed	email	Your booking 928c7ac6-df7e-4c6c-8924-9ec8472ded15 is confirmed.	2026-04-04 08:51:53.145837
766f0423-5dc1-4b93-b55b-115391877283	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2a5c1d0f-a7a9-450e-bded-29846ec08b30	booking.confirmed	push	Your booking 2a5c1d0f-a7a9-450e-bded-29846ec08b30 is confirmed.	2026-04-04 08:52:36.383578
1d7547e3-555a-4452-b23a-27d4d41027c0	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2a5c1d0f-a7a9-450e-bded-29846ec08b30	booking.confirmed	sms	Your booking 2a5c1d0f-a7a9-450e-bded-29846ec08b30 is confirmed.	2026-04-04 08:52:36.385124
b85e1a8b-f2d4-4144-b572-41c197b2ea4e	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2a5c1d0f-a7a9-450e-bded-29846ec08b30	booking.confirmed	email	Your booking 2a5c1d0f-a7a9-450e-bded-29846ec08b30 is confirmed.	2026-04-04 08:52:36.386915
1eef4031-7b9e-4484-8a5e-867db923c87a	e83817d3-04f0-4469-833e-f13a5b8d9d2f	fda32288-95af-41bf-8c03-56c9fd6c09c4	booking.confirmed	push	Your booking fda32288-95af-41bf-8c03-56c9fd6c09c4 is confirmed.	2026-04-04 08:52:37.233335
c99b7a92-d2ab-48c2-915c-55c93778ede6	e83817d3-04f0-4469-833e-f13a5b8d9d2f	fda32288-95af-41bf-8c03-56c9fd6c09c4	booking.confirmed	sms	Your booking fda32288-95af-41bf-8c03-56c9fd6c09c4 is confirmed.	2026-04-04 08:52:37.235893
c2e65aa8-a6ef-437c-8af1-a38424b3c5f4	e83817d3-04f0-4469-833e-f13a5b8d9d2f	fda32288-95af-41bf-8c03-56c9fd6c09c4	booking.confirmed	email	Your booking fda32288-95af-41bf-8c03-56c9fd6c09c4 is confirmed.	2026-04-04 08:52:37.237866
6fb67156-42d3-431b-94bb-1b6fc3bd4720	e83817d3-04f0-4469-833e-f13a5b8d9d2f	e93d455f-00d3-40dd-809c-305c90488a3c	booking.confirmed	push	Your booking e93d455f-00d3-40dd-809c-305c90488a3c is confirmed.	2026-04-04 08:52:37.242522
5cb2e221-f7e6-4f78-87a6-e54eb6c2feb9	e83817d3-04f0-4469-833e-f13a5b8d9d2f	e93d455f-00d3-40dd-809c-305c90488a3c	booking.confirmed	sms	Your booking e93d455f-00d3-40dd-809c-305c90488a3c is confirmed.	2026-04-04 08:52:37.244001
2772f975-1cae-4cbb-a7bf-67d02d83b4c9	e83817d3-04f0-4469-833e-f13a5b8d9d2f	e93d455f-00d3-40dd-809c-305c90488a3c	booking.confirmed	email	Your booking e93d455f-00d3-40dd-809c-305c90488a3c is confirmed.	2026-04-04 08:52:37.245292
67cc09e0-dbdf-4d3b-997a-3dfb4c33b250	e83817d3-04f0-4469-833e-f13a5b8d9d2f	a36c30f9-2199-43f0-b658-907779cff93c	booking.confirmed	push	Your booking a36c30f9-2199-43f0-b658-907779cff93c is confirmed.	2026-04-04 08:52:37.248554
3a6d7e8c-6773-4414-8f3b-b08b235e8d32	e83817d3-04f0-4469-833e-f13a5b8d9d2f	a36c30f9-2199-43f0-b658-907779cff93c	booking.confirmed	sms	Your booking a36c30f9-2199-43f0-b658-907779cff93c is confirmed.	2026-04-04 08:52:37.250192
96afa935-6f1a-4172-acb3-4f89b2360a1d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	a36c30f9-2199-43f0-b658-907779cff93c	booking.confirmed	email	Your booking a36c30f9-2199-43f0-b658-907779cff93c is confirmed.	2026-04-04 08:52:37.251197
43c41556-6ed8-4566-b331-89df734b6a8f	e83817d3-04f0-4469-833e-f13a5b8d9d2f	03476c7f-fa64-4081-bc32-5fb9c85aab51	booking.confirmed	push	Your booking 03476c7f-fa64-4081-bc32-5fb9c85aab51 is confirmed.	2026-04-04 08:52:38.059428
6da2b6a0-c8b9-4a3a-babe-8f024d8b6f48	e83817d3-04f0-4469-833e-f13a5b8d9d2f	03476c7f-fa64-4081-bc32-5fb9c85aab51	booking.confirmed	sms	Your booking 03476c7f-fa64-4081-bc32-5fb9c85aab51 is confirmed.	2026-04-04 08:52:38.060969
f2b1246c-3baf-4435-9ad4-61a2659f8385	e83817d3-04f0-4469-833e-f13a5b8d9d2f	03476c7f-fa64-4081-bc32-5fb9c85aab51	booking.confirmed	email	Your booking 03476c7f-fa64-4081-bc32-5fb9c85aab51 is confirmed.	2026-04-04 08:52:38.062303
678abc99-e073-4d5a-85ab-7f226251af83	27b8e42a-e893-441b-a466-cc7d9a90f633	19b0fada-f680-4168-82ca-61adf041026f	booking.confirmed	push	Your booking 19b0fada-f680-4168-82ca-61adf041026f is confirmed.	2026-04-04 08:57:07.683454
09cbd86e-924f-4fd3-825f-b55e39dc48b2	27b8e42a-e893-441b-a466-cc7d9a90f633	19b0fada-f680-4168-82ca-61adf041026f	booking.confirmed	sms	Your booking 19b0fada-f680-4168-82ca-61adf041026f is confirmed.	2026-04-04 08:57:07.685196
227ac8b7-0c67-498c-8f8d-0575f066e536	27b8e42a-e893-441b-a466-cc7d9a90f633	19b0fada-f680-4168-82ca-61adf041026f	booking.confirmed	email	Your booking 19b0fada-f680-4168-82ca-61adf041026f is confirmed.	2026-04-04 08:57:07.686399
c73f4205-a263-4009-b38b-aa7cac037f23	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	db655139-a079-4beb-a08a-0cd9f8cf29db	booking.confirmed	push	Your booking db655139-a079-4beb-a08a-0cd9f8cf29db is confirmed.	2026-04-04 08:59:09.494963
7957be8a-1071-401d-b1c7-e853a63d9feb	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	db655139-a079-4beb-a08a-0cd9f8cf29db	booking.confirmed	sms	Your booking db655139-a079-4beb-a08a-0cd9f8cf29db is confirmed.	2026-04-04 08:59:09.496891
386073ff-4db2-4240-b62d-4332dd2e562d	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	db655139-a079-4beb-a08a-0cd9f8cf29db	booking.confirmed	email	Your booking db655139-a079-4beb-a08a-0cd9f8cf29db is confirmed.	2026-04-04 08:59:09.497905
237c8a39-8ca4-443f-aa65-676caa1af91e	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	7688b4c8-c41c-4966-9a7c-c9d4c7bfe087	booking.cancelled	push	Your booking 7688b4c8-c41c-4966-9a7c-c9d4c7bfe087 was cancelled.	2026-04-04 08:59:15.979261
609b4f9b-a5f0-4d68-961c-00054e0b5fd8	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	7688b4c8-c41c-4966-9a7c-c9d4c7bfe087	booking.cancelled	sms	Your booking 7688b4c8-c41c-4966-9a7c-c9d4c7bfe087 was cancelled.	2026-04-04 08:59:15.981049
083ebd44-58c6-49e5-bd27-88aa05f9b23b	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	db655139-a079-4beb-a08a-0cd9f8cf29db	booking.cancelled	push	Your booking db655139-a079-4beb-a08a-0cd9f8cf29db was cancelled.	2026-04-04 09:00:06.996309
44f6a5ab-3068-46f6-8ce4-2e638203d769	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	db655139-a079-4beb-a08a-0cd9f8cf29db	booking.cancelled	sms	Your booking db655139-a079-4beb-a08a-0cd9f8cf29db was cancelled.	2026-04-04 09:00:06.998066
36662af6-b3b9-493e-a807-572aa2fe92a1	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	0b8318d5-1312-4f08-9ced-07107c089b07	booking.confirmed	push	Your booking 0b8318d5-1312-4f08-9ced-07107c089b07 is confirmed.	2026-04-04 09:00:19.11262
59cb8ccd-7dc4-4009-8e9f-ceb1189c60ed	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	0b8318d5-1312-4f08-9ced-07107c089b07	booking.confirmed	sms	Your booking 0b8318d5-1312-4f08-9ced-07107c089b07 is confirmed.	2026-04-04 09:00:19.114404
d8f81988-39de-474b-81e4-ead4f2633e44	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	0b8318d5-1312-4f08-9ced-07107c089b07	booking.confirmed	email	Your booking 0b8318d5-1312-4f08-9ced-07107c089b07 is confirmed.	2026-04-04 09:00:19.115679
af357ef4-7a14-4cbb-ae9e-4e557fcd3ac6	e83817d3-04f0-4469-833e-f13a5b8d9d2f	9bd5b11e-30d0-412d-b3ec-d567fb0dd769	booking.confirmed	push	Your booking 9bd5b11e-30d0-412d-b3ec-d567fb0dd769 is confirmed.	2026-04-04 09:10:01.185072
c20c6a35-9692-47f9-9f7d-0a71afda35af	e83817d3-04f0-4469-833e-f13a5b8d9d2f	9bd5b11e-30d0-412d-b3ec-d567fb0dd769	booking.confirmed	sms	Your booking 9bd5b11e-30d0-412d-b3ec-d567fb0dd769 is confirmed.	2026-04-04 09:10:01.187727
dc31d3bb-68df-4e52-8734-34ddf8e19984	e83817d3-04f0-4469-833e-f13a5b8d9d2f	9bd5b11e-30d0-412d-b3ec-d567fb0dd769	booking.confirmed	email	Your booking 9bd5b11e-30d0-412d-b3ec-d567fb0dd769 is confirmed.	2026-04-04 09:10:01.188979
d66ab7ab-517d-4940-ac20-15247d904017	e83817d3-04f0-4469-833e-f13a5b8d9d2f	351226b2-e18c-4e58-b68a-bfbafbebfb34	booking.failed	push	Booking 351226b2-e18c-4e58-b68a-bfbafbebfb34 could not be confirmed. Please try again.	2026-04-04 09:10:02.035865
29978c16-f183-439e-9b46-65cf312fb27e	e83817d3-04f0-4469-833e-f13a5b8d9d2f	351226b2-e18c-4e58-b68a-bfbafbebfb34	booking.failed	email	Booking 351226b2-e18c-4e58-b68a-bfbafbebfb34 could not be confirmed. Please try again.	2026-04-04 09:10:02.037656
de8b9a08-5b25-40ec-9a25-49e31404685a	e83817d3-04f0-4469-833e-f13a5b8d9d2f	51b6d9c5-f71f-4063-a564-d14e7c316bb5	booking.confirmed	push	Your booking 51b6d9c5-f71f-4063-a564-d14e7c316bb5 is confirmed.	2026-04-04 09:10:02.04008
f3502675-81e3-4f0f-a761-4ac622cfcabc	e83817d3-04f0-4469-833e-f13a5b8d9d2f	51b6d9c5-f71f-4063-a564-d14e7c316bb5	booking.confirmed	sms	Your booking 51b6d9c5-f71f-4063-a564-d14e7c316bb5 is confirmed.	2026-04-04 09:10:02.041538
6a651944-ce7a-4dec-8463-4474c76774c1	e83817d3-04f0-4469-833e-f13a5b8d9d2f	51b6d9c5-f71f-4063-a564-d14e7c316bb5	booking.confirmed	email	Your booking 51b6d9c5-f71f-4063-a564-d14e7c316bb5 is confirmed.	2026-04-04 09:10:02.042909
ffe5630d-66f3-48f7-b0b2-f06a7158c635	e83817d3-04f0-4469-833e-f13a5b8d9d2f	1968a902-b369-4bf0-912b-04fc16786cec	booking.confirmed	push	Your booking 1968a902-b369-4bf0-912b-04fc16786cec is confirmed.	2026-04-04 09:10:02.049511
001e0d95-3ac7-4417-949e-9977599e707e	e83817d3-04f0-4469-833e-f13a5b8d9d2f	1968a902-b369-4bf0-912b-04fc16786cec	booking.confirmed	sms	Your booking 1968a902-b369-4bf0-912b-04fc16786cec is confirmed.	2026-04-04 09:10:02.050839
e34b4c31-d693-4331-931b-c2bfc2fefaac	e83817d3-04f0-4469-833e-f13a5b8d9d2f	1968a902-b369-4bf0-912b-04fc16786cec	booking.confirmed	email	Your booking 1968a902-b369-4bf0-912b-04fc16786cec is confirmed.	2026-04-04 09:10:02.051971
0cdcdad3-c97c-4210-9c9c-5fd237c9068e	e83817d3-04f0-4469-833e-f13a5b8d9d2f	7e475cb7-c49d-43e3-8836-bb80d1a5ed64	booking.confirmed	push	Your booking 7e475cb7-c49d-43e3-8836-bb80d1a5ed64 is confirmed.	2026-04-04 09:10:02.869639
2566efc4-9d71-4a5c-9909-e4d038865f27	e83817d3-04f0-4469-833e-f13a5b8d9d2f	7e475cb7-c49d-43e3-8836-bb80d1a5ed64	booking.confirmed	sms	Your booking 7e475cb7-c49d-43e3-8836-bb80d1a5ed64 is confirmed.	2026-04-04 09:10:02.871428
cefb302b-b70c-42d2-b1af-5f6f294885bd	e83817d3-04f0-4469-833e-f13a5b8d9d2f	7e475cb7-c49d-43e3-8836-bb80d1a5ed64	booking.confirmed	email	Your booking 7e475cb7-c49d-43e3-8836-bb80d1a5ed64 is confirmed.	2026-04-04 09:10:02.872825
0fe25f36-e43b-4306-b529-737b0d92c2a0	e83817d3-04f0-4469-833e-f13a5b8d9d2f	d51f2799-249b-4872-9415-de7a25c79b3c	booking.confirmed	push	Your booking d51f2799-249b-4872-9415-de7a25c79b3c is confirmed.	2026-04-04 09:22:53.497609
04e820ed-16f6-4d9d-aa3c-1e0596a6f161	e83817d3-04f0-4469-833e-f13a5b8d9d2f	d51f2799-249b-4872-9415-de7a25c79b3c	booking.confirmed	sms	Your booking d51f2799-249b-4872-9415-de7a25c79b3c is confirmed.	2026-04-04 09:22:53.499627
25cff540-30e1-4674-8ac4-04159a4a7660	e83817d3-04f0-4469-833e-f13a5b8d9d2f	d51f2799-249b-4872-9415-de7a25c79b3c	booking.confirmed	email	Your booking d51f2799-249b-4872-9415-de7a25c79b3c is confirmed.	2026-04-04 09:22:53.500956
7c5267de-0d4a-4f3d-be21-957db6b5c5df	e83817d3-04f0-4469-833e-f13a5b8d9d2f	42f5def3-c5fc-4b12-891b-1494c5d2eba1	booking.confirmed	push	Your booking 42f5def3-c5fc-4b12-891b-1494c5d2eba1 is confirmed.	2026-04-04 09:22:54.316681
b0ede862-3438-4363-bf23-48dd2f8ecb3f	e83817d3-04f0-4469-833e-f13a5b8d9d2f	42f5def3-c5fc-4b12-891b-1494c5d2eba1	booking.confirmed	sms	Your booking 42f5def3-c5fc-4b12-891b-1494c5d2eba1 is confirmed.	2026-04-04 09:22:54.318467
bc141eb0-240f-415e-9eb6-a3e095b3ac48	e83817d3-04f0-4469-833e-f13a5b8d9d2f	42f5def3-c5fc-4b12-891b-1494c5d2eba1	booking.confirmed	email	Your booking 42f5def3-c5fc-4b12-891b-1494c5d2eba1 is confirmed.	2026-04-04 09:22:54.319844
2a4754a0-7e3a-4824-8ad8-96de7492ca6a	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	8cf09e83-ea08-4225-8f15-ebbdf364fe3a	booking.confirmed	push	Your booking 8cf09e83-ea08-4225-8f15-ebbdf364fe3a is confirmed.	2026-04-04 09:30:39.360267
436c7eff-001e-450e-b902-ae6615ff404e	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	8cf09e83-ea08-4225-8f15-ebbdf364fe3a	booking.confirmed	sms	Your booking 8cf09e83-ea08-4225-8f15-ebbdf364fe3a is confirmed.	2026-04-04 09:30:39.363336
e6634723-5b2e-4c5b-be49-d1185575f0e7	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	8cf09e83-ea08-4225-8f15-ebbdf364fe3a	booking.confirmed	email	Your booking 8cf09e83-ea08-4225-8f15-ebbdf364fe3a is confirmed.	2026-04-04 09:30:39.366107
7e948844-c1e1-4fab-8c4b-695a03cc6323	824272c8-6988-4174-8a6c-6e6b1aff23b2	2d417377-0315-4df2-b7d1-f9ea8e3c98c0	booking.confirmed	push	Your booking 2d417377-0315-4df2-b7d1-f9ea8e3c98c0 is confirmed.	2026-04-04 09:31:38.106901
460d3f9c-3a2c-4d14-b11e-de34bd57a2f7	824272c8-6988-4174-8a6c-6e6b1aff23b2	2d417377-0315-4df2-b7d1-f9ea8e3c98c0	booking.confirmed	sms	Your booking 2d417377-0315-4df2-b7d1-f9ea8e3c98c0 is confirmed.	2026-04-04 09:31:38.109787
efeca225-f159-4898-9106-3077a785b2aa	824272c8-6988-4174-8a6c-6e6b1aff23b2	2d417377-0315-4df2-b7d1-f9ea8e3c98c0	booking.confirmed	email	Your booking 2d417377-0315-4df2-b7d1-f9ea8e3c98c0 is confirmed.	2026-04-04 09:31:38.111673
ecaf768b-8958-4a54-8242-8cd8be8ff5ae	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	9a3af9eb-5401-473b-9182-297acc0963c7	booking.confirmed	push	Your booking 9a3af9eb-5401-473b-9182-297acc0963c7 is confirmed.	2026-04-04 09:35:06.999197
22751e40-afdc-4c30-8a86-677d3765787c	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	9a3af9eb-5401-473b-9182-297acc0963c7	booking.confirmed	sms	Your booking 9a3af9eb-5401-473b-9182-297acc0963c7 is confirmed.	2026-04-04 09:35:07.001589
342ae469-0aeb-490a-9cbc-e3f465642af4	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	9a3af9eb-5401-473b-9182-297acc0963c7	booking.confirmed	email	Your booking 9a3af9eb-5401-473b-9182-297acc0963c7 is confirmed.	2026-04-04 09:35:07.003579
d498b41b-03ee-4c8d-90d6-932927dbef69	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	d9690f73-6749-425f-8c7b-09fd107c3371	booking.confirmed	push	Your booking d9690f73-6749-425f-8c7b-09fd107c3371 is confirmed.	2026-04-04 09:49:01.812122
512ff500-0667-4644-942f-a137ca10320f	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	d9690f73-6749-425f-8c7b-09fd107c3371	booking.confirmed	sms	Your booking d9690f73-6749-425f-8c7b-09fd107c3371 is confirmed.	2026-04-04 09:49:01.816573
7b314051-dbad-44cb-aeca-e01396fb9ef1	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	d9690f73-6749-425f-8c7b-09fd107c3371	booking.confirmed	email	Your booking d9690f73-6749-425f-8c7b-09fd107c3371 is confirmed.	2026-04-04 09:49:01.818017
\.


--
-- Data for Name: segment_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.segment_reservations (id, booking_id, segment_id, region, time_slot_start, time_slot_end, status, created_at) FROM stdin;
fc93109e-ae6f-46c3-923b-3f79e6943571	928c7ac6-df7e-4c6c-8924-9ec8472ded15	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 09:00:00	2026-04-04 10:00:00	CONFIRMED	2026-04-04 08:51:53.134871
6d291332-13d5-4cac-a102-f662ce83eb19	2a5c1d0f-a7a9-450e-bded-29846ec08b30	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 09:00:00	2026-04-04 10:00:00	CONFIRMED	2026-04-04 08:52:36.373859
aca0f19c-d9ce-4b23-903e-815700746f0f	fda32288-95af-41bf-8c03-56c9fd6c09c4	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 08:52:37.202638
5cf23f24-a9cc-4a24-a859-dbf343ce307f	e93d455f-00d3-40dd-809c-305c90488a3c	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 08:52:37.230741
30ee70e4-7fbe-43da-83ed-952ac2b0332c	a36c30f9-2199-43f0-b658-907779cff93c	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 08:52:37.239559
59cea47e-6b13-4716-87e2-354a8ea5f1a5	03476c7f-fa64-4081-bc32-5fb9c85aab51	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 08:52:38.052214
effbf8f2-7340-4fae-8b4b-b35c47fb5c89	03476c7f-fa64-4081-bc32-5fb9c85aab51	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	EU_WEST_UK	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 08:52:38.05222
19b32039-e081-469c-9f04-a7ed540d04f7	19b0fada-f680-4168-82ca-61adf041026f	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 09:00:00	2026-04-04 10:00:00	CONFIRMED	2026-04-04 08:57:07.675353
3a9c1323-0d22-495b-985f-4b03edbb4d3f	db655139-a079-4beb-a08a-0cd9f8cf29db	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 09:00:00	2026-04-04 10:00:00	CANCELLED	2026-04-04 08:59:09.486647
03fec6bc-4ce3-4bbe-891b-5d5a54c57119	0b8318d5-1312-4f08-9ced-07107c089b07	0dfcd849-f0b8-5213-b721-44b067f63dd3	EU_WEST_FRANCE	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:00:19.105805
0f804980-ca91-4627-85fd-ae0224a94b14	0b8318d5-1312-4f08-9ced-07107c089b07	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:00:19.105811
ab8840a0-81ad-4d11-923f-7d7454468abc	9bd5b11e-30d0-412d-b3ec-d567fb0dd769	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:10:01.162521
bb0395ce-ca65-40cd-ac47-5f02a7b897c5	51b6d9c5-f71f-4063-a564-d14e7c316bb5	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 12:00:00	2026-04-04 13:00:00	CONFIRMED	2026-04-04 09:10:02.027386
24cd9bc3-55f9-4e9e-aab3-7f8b509f0e04	1968a902-b369-4bf0-912b-04fc16786cec	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 12:00:00	2026-04-04 13:00:00	CONFIRMED	2026-04-04 09:10:02.036619
98e9c6ad-8b1a-4bfc-9c56-a33eebef4f1b	7e475cb7-c49d-43e3-8836-bb80d1a5ed64	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:10:02.862017
99ca9259-c7f4-4a47-b8cf-c44db23aa135	7e475cb7-c49d-43e3-8836-bb80d1a5ed64	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	EU_WEST_UK	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:10:02.862021
ebc3cb0b-4835-4365-83a9-4abfe1e05718	d51f2799-249b-4872-9415-de7a25c79b3c	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:22:53.485284
84ece907-066b-4afe-894f-1126cb7639aa	42f5def3-c5fc-4b12-891b-1494c5d2eba1	c8476fce-4136-5a82-a985-be50e80de41d	EU_WEST_IRELAND	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:22:54.307335
f95365d9-83c3-48b9-bb5d-8ef30b042372	42f5def3-c5fc-4b12-891b-1494c5d2eba1	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	EU_WEST_UK	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:22:54.307339
b37c3f10-82a2-4f4b-a981-ce826ca176d8	8cf09e83-ea08-4225-8f15-ebbdf364fe3a	e71ba8fb-58a5-41f3-9383-7159375d2f6f	EU_WEST_IRELAND	2026-04-05 11:00:00	2026-04-05 12:00:00	CONFIRMED	2026-04-04 09:30:39.346145
c4315c11-0bf7-4786-b8fa-d567baa143a0	8cf09e83-ea08-4225-8f15-ebbdf364fe3a	9aedc4fe-365e-4f44-97a9-46449d50750c	EU_WEST_UK	2026-04-05 12:00:00	2026-04-05 13:00:00	CONFIRMED	2026-04-04 09:30:39.346152
e1af3bbf-dd1b-4514-a7d1-29850c4edc2f	2d417377-0315-4df2-b7d1-f9ea8e3c98c0	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	EU_WEST_UK	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:31:38.098485
f6e224e8-a29c-4699-828f-e4563040a522	9a3af9eb-5401-473b-9182-297acc0963c7	e71ba8fb-58a5-41f3-9383-7159375d2f6f	EU_WEST_IRELAND	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:35:06.983827
c333b1fd-4b5c-445f-b377-783df240e3a2	9a3af9eb-5401-473b-9182-297acc0963c7	9aedc4fe-365e-4f44-97a9-46449d50750c	EU_WEST_UK	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:35:06.983834
d3104688-80a6-46ba-9952-224b2d719fa7	d9690f73-6749-425f-8c7b-09fd107c3371	5bd68e8c-963d-4b1f-97cf-6f443ec457cd	EU_WEST_IRELAND	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:49:01.774803
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: region_france; Owner: -
--

COPY region_france.reservations (id, booking_id, segment_id, driver_id, time_slot_start, time_slot_end, status, created_at) FROM stdin;
711e5bdf-7972-4fee-b3f0-4bd32f2b361f	0b8318d5-1312-4f08-9ced-07107c089b07	0dfcd849-f0b8-5213-b721-44b067f63dd3	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:00:19.099726
\.


--
-- Data for Name: road_segments; Type: TABLE DATA; Schema: region_france; Owner: -
--

COPY region_france.road_segments (id, name, start_point_lat, start_point_lng, end_point_lat, end_point_lng, max_capacity_per_slot, created_at) FROM stdin;
0dfcd849-f0b8-5213-b721-44b067f63dd3	France-Default	48.8566	2.3522	45.764	4.8357	200	2026-03-30 12:30:25.712139
cba0d0c2-2e05-47f7-b8e3-9609974b61c8	Paris-Lyon	48.8566	2.3522	45.764	4.8357	200	2026-04-04 09:26:14.064244
59c63fa2-d01d-4bd9-9705-618449e50c0b	Paris-Marseille	48.8566	2.3522	43.2965	5.3698	180	2026-04-04 09:26:14.065558
c011e67d-d165-4977-a538-bb06dfb5a09e	Paris-Bordeaux	48.8566	2.3522	44.8378	-0.5792	170	2026-04-04 09:26:14.066149
943d12df-7624-453f-a4b5-35d8f9650372	Paris-Lille	48.8566	2.3522	50.6292	3.0573	190	2026-04-04 09:26:14.066592
8ee2ad0e-ebb7-4b7f-851d-8226a68813a1	Lyon-Marseille	45.764	4.8357	43.2965	5.3698	150	2026-04-04 09:26:14.067381
34f65df2-694e-482d-9fd9-530da96a9ccc	Bordeaux-Toulouse	44.8378	-0.5792	43.6047	1.4442	130	2026-04-04 09:26:14.067811
e1fc76dd-d4f2-44ef-8d7a-6966c27f84b9	Paris-Calais	48.8566	2.3522	50.9513	1.8587	160	2026-04-04 09:26:14.068288
bde345b6-d49d-4e3d-8465-7ef35d2a35ae	Calais-Dunkirk	50.9513	1.8587	51.0344	2.377	120	2026-04-04 09:26:14.06876
8d60d3ec-0582-471a-880b-5d1bf0e19e4f	Nice-Marseille	43.7102	7.262	43.2965	5.3698	140	2026-04-04 09:26:14.069158
d400acdc-6f69-472b-8872-6c8b1579f679	Paris-Strasbourg	48.8566	2.3522	48.5734	7.7521	160	2026-04-04 09:26:14.069597
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: region_ireland; Owner: -
--

COPY region_ireland.reservations (id, booking_id, segment_id, driver_id, time_slot_start, time_slot_end, status, created_at) FROM stdin;
382fdb5f-bd6d-4537-b0f8-a4141c18f22c	928c7ac6-df7e-4c6c-8924-9ec8472ded15	c8476fce-4136-5a82-a985-be50e80de41d	8db41428-a58c-40e1-afbe-716906218c8c	2026-04-04 09:00:00	2026-04-04 10:00:00	CONFIRMED	2026-04-04 08:51:53.129649
d31c93b3-ad71-4bda-9957-9b51678bf56b	2a5c1d0f-a7a9-450e-bded-29846ec08b30	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 09:00:00	2026-04-04 10:00:00	CONFIRMED	2026-04-04 08:52:36.371235
43d3bbf9-07d1-4c22-8956-5c3bcf971527	fda32288-95af-41bf-8c03-56c9fd6c09c4	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 08:52:37.197906
6a2db87e-1a2f-4676-9178-197df10528c4	e93d455f-00d3-40dd-809c-305c90488a3c	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 08:52:37.209529
b9f958cb-c4ee-4dfa-bb0e-ecc897cb2a28	a36c30f9-2199-43f0-b658-907779cff93c	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 08:52:37.231874
5250a21e-1f97-447a-9d0f-93c79c3921c8	03476c7f-fa64-4081-bc32-5fb9c85aab51	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 08:52:38.047254
4d7b8250-1f5a-440b-b22b-cabe0bd53044	19b0fada-f680-4168-82ca-61adf041026f	c8476fce-4136-5a82-a985-be50e80de41d	27b8e42a-e893-441b-a466-cc7d9a90f633	2026-04-04 09:00:00	2026-04-04 10:00:00	CONFIRMED	2026-04-04 08:57:07.673031
2e3283cf-9a7f-4597-be02-c95173dac906	0b8318d5-1312-4f08-9ced-07107c089b07	c8476fce-4136-5a82-a985-be50e80de41d	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:00:19.099726
704b88aa-e9e6-4b60-8b9d-f27b40a448b2	9bd5b11e-30d0-412d-b3ec-d567fb0dd769	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:10:01.156443
f7532f9a-c4ed-4c97-811d-62d780b136a7	51b6d9c5-f71f-4063-a564-d14e7c316bb5	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 12:00:00	2026-04-04 13:00:00	CONFIRMED	2026-04-04 09:10:02.005436
9c5eee37-83e8-4a92-a0a6-cc861579da51	1968a902-b369-4bf0-912b-04fc16786cec	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 12:00:00	2026-04-04 13:00:00	CONFIRMED	2026-04-04 09:10:02.028363
d9d4ba7c-1ea9-4bb1-9a21-c9ce129bc61b	7e475cb7-c49d-43e3-8836-bb80d1a5ed64	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:10:02.857654
80bd0d58-6f7a-4554-b263-ba32e02a81d7	d51f2799-249b-4872-9415-de7a25c79b3c	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:22:53.47815
ba87f7ca-2d6b-4aad-bb5a-08f520a297af	42f5def3-c5fc-4b12-891b-1494c5d2eba1	c8476fce-4136-5a82-a985-be50e80de41d	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:22:54.300489
1a8ecb02-38ff-484e-9ef4-d4d4ba54305b	8cf09e83-ea08-4225-8f15-ebbdf364fe3a	e71ba8fb-58a5-41f3-9383-7159375d2f6f	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	2026-04-05 11:00:00	2026-04-05 12:00:00	CONFIRMED	2026-04-04 09:30:39.335211
e12bd969-fe3d-4bc2-a72a-637984054419	9a3af9eb-5401-473b-9182-297acc0963c7	e71ba8fb-58a5-41f3-9383-7159375d2f6f	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:35:06.976077
bbf5efee-8d80-4390-9ca6-d3525e2cd4fb	d9690f73-6749-425f-8c7b-09fd107c3371	5bd68e8c-963d-4b1f-97cf-6f443ec457cd	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:49:01.758606
b368e6fd-1ce8-4460-b2a6-b6e436d7b942	7688b4c8-c41c-4966-9a7c-c9d4c7bfe087	c8476fce-4136-5a82-a985-be50e80de41d	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	2026-03-30 13:00:00	2026-03-30 14:00:00	CANCELLED	2026-03-30 12:32:15.956157
2e75cf94-6be5-4afd-9055-32893dc4d092	db655139-a079-4beb-a08a-0cd9f8cf29db	c8476fce-4136-5a82-a985-be50e80de41d	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	2026-04-04 09:00:00	2026-04-04 10:00:00	CANCELLED	2026-04-04 08:59:09.48335
\.


--
-- Data for Name: road_segments; Type: TABLE DATA; Schema: region_ireland; Owner: -
--

COPY region_ireland.road_segments (id, name, start_point_lat, start_point_lng, end_point_lat, end_point_lng, max_capacity_per_slot, created_at) FROM stdin;
c8476fce-4136-5a82-a985-be50e80de41d	Ireland-Default	53.3498	-6.2603	51.8985	-8.4756	150	2026-03-30 12:30:25.710735
7af4ee6c-94ee-48f2-b934-9e7a2d6e17d7	Dublin-Cork	53.3498	-6.2603	51.8985	-8.4756	150	2026-04-04 09:26:14.047219
5bd68e8c-963d-4b1f-97cf-6f443ec457cd	Dublin-Galway	53.3498	-6.2603	53.2707	-9.0568	120	2026-04-04 09:26:14.049596
68abde50-a70c-4bed-9754-6d26e7a8d59e	Dublin-Limerick	53.3498	-6.2603	52.6638	-8.6267	130	2026-04-04 09:26:14.050368
1a607c8f-72a8-4ca6-b06c-a2c3c4959db3	Dublin-Belfast	53.3498	-6.2603	54.5973	-5.9301	180	2026-04-04 09:26:14.051226
b28dc811-c5e1-439d-bbfd-bdece3682568	Cork-Limerick	51.8985	-8.4756	52.6638	-8.6267	100	2026-04-04 09:26:14.051934
1d41e9ad-bc0d-427e-a927-e824f7f4ec78	Galway-Limerick	53.2707	-9.0568	52.6638	-8.6267	80	2026-04-04 09:26:14.052734
cbced22f-9552-4fe6-a706-dc3f79455609	Dublin-Waterford	53.3498	-6.2603	52.2593	-7.1101	90	2026-04-04 09:26:14.05361
c4d1d257-621e-4ab7-96ed-e730cd8b99fc	Cork-Waterford	51.8985	-8.4756	52.2593	-7.1101	70	2026-04-04 09:26:14.054762
e75ad65c-c0b4-4f63-9821-2f10984326a7	Galway-Sligo	53.2707	-9.0568	54.2766	-8.4761	60	2026-04-04 09:26:14.055518
e71ba8fb-58a5-41f3-9383-7159375d2f6f	Dublin-Holyhead_Ferry	53.3498	-6.2603	53.3083	-4.6325	200	2026-04-04 09:26:14.056157
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: region_uk; Owner: -
--

COPY region_uk.reservations (id, booking_id, segment_id, driver_id, time_slot_start, time_slot_end, status, created_at) FROM stdin;
a5177de5-3b42-414a-9fea-9dd11f7c2f05	03476c7f-fa64-4081-bc32-5fb9c85aab51	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 08:52:38.047254
0d3b2e24-8eac-49e3-a165-fc46e9c347f0	7e475cb7-c49d-43e3-8836-bb80d1a5ed64	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:10:02.857654
480f9f7c-0774-496c-8630-6bccc117c108	42f5def3-c5fc-4b12-891b-1494c5d2eba1	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	e83817d3-04f0-4469-833e-f13a5b8d9d2f	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:22:54.300489
00cd4115-7a0d-4510-8d4a-bc77e11390ee	8cf09e83-ea08-4225-8f15-ebbdf364fe3a	9aedc4fe-365e-4f44-97a9-46449d50750c	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	2026-04-05 12:00:00	2026-04-05 13:00:00	CONFIRMED	2026-04-04 09:30:39.335211
12c4b912-0934-4fde-ac77-ac68214540a5	2d417377-0315-4df2-b7d1-f9ea8e3c98c0	5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	824272c8-6988-4174-8a6c-6e6b1aff23b2	2026-04-04 10:00:00	2026-04-04 11:00:00	CONFIRMED	2026-04-04 09:31:38.09412
d4377010-33c9-4d1a-baff-debff0689bf2	9a3af9eb-5401-473b-9182-297acc0963c7	9aedc4fe-365e-4f44-97a9-46449d50750c	7ea0ef7b-e1d9-490b-a9cb-607ac09d8a95	2026-04-04 11:00:00	2026-04-04 12:00:00	CONFIRMED	2026-04-04 09:35:06.976077
\.


--
-- Data for Name: road_segments; Type: TABLE DATA; Schema: region_uk; Owner: -
--

COPY region_uk.road_segments (id, name, start_point_lat, start_point_lng, end_point_lat, end_point_lng, max_capacity_per_slot, created_at) FROM stdin;
5ab73b95-6aa1-56a2-bede-05c0ecf43a7a	UK-Default	51.5074	-0.1278	53.4808	-2.2426	200	2026-03-30 12:30:25.711483
659e1512-771a-4218-8147-3d28a6bbaf88	London-Birmingham	51.5074	-0.1278	52.4862	-1.8904	200	2026-04-04 09:26:14.05693
402ea2dd-db79-4cc1-b413-8d213041ae51	London-Manchester	51.5074	-0.1278	53.4808	-2.2426	180	2026-04-04 09:26:14.05839
5d180019-4127-4e8f-a819-768c0c9b4c2c	London-Edinburgh	51.5074	-0.1278	55.9533	-3.1883	150	2026-04-04 09:26:14.05899
4bdd2116-7ae5-40d6-a9e9-2cbf7f52dd7d	Birmingham-Manchester	52.4862	-1.8904	53.4808	-2.2426	160	2026-04-04 09:26:14.059613
06c35740-7e4c-4fa7-ae2b-74b231112146	Manchester-Leeds	53.4808	-2.2426	53.8008	-1.5491	140	2026-04-04 09:26:14.060163
3167ab87-ee82-4911-b5c7-d40155b07150	London-Bristol	51.5074	-0.1278	51.4545	-2.5879	170	2026-04-04 09:26:14.060746
0a0dfc0b-cefb-480c-be95-3a7c27541b2a	Bristol-Cardiff	51.4545	-2.5879	51.4816	-3.1791	120	2026-04-04 09:26:14.061318
628f0352-099e-4d60-9a30-9eb49c36c4a6	Edinburgh-Glasgow	55.9533	-3.1883	55.8642	-4.2518	130	2026-04-04 09:26:14.06202
b5b99e93-964c-4e59-aa84-557ae08688e2	London-Dover	51.5074	-0.1278	51.1279	1.3134	160	2026-04-04 09:26:14.062787
9aedc4fe-365e-4f44-97a9-46449d50750c	Holyhead-Birmingham	53.3083	-4.6325	52.4862	-1.8904	110	2026-04-04 09:26:14.06349
\.


--
-- Name: booking_events booking_events_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.booking_events
    ADD CONSTRAINT booking_events_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: segment_reservations segment_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.segment_reservations
    ADD CONSTRAINT segment_reservations_pkey PRIMARY KEY (id);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: region_france; Owner: -
--

ALTER TABLE ONLY region_france.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: road_segments road_segments_pkey; Type: CONSTRAINT; Schema: region_france; Owner: -
--

ALTER TABLE ONLY region_france.road_segments
    ADD CONSTRAINT road_segments_pkey PRIMARY KEY (id);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: region_ireland; Owner: -
--

ALTER TABLE ONLY region_ireland.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: road_segments road_segments_pkey; Type: CONSTRAINT; Schema: region_ireland; Owner: -
--

ALTER TABLE ONLY region_ireland.road_segments
    ADD CONSTRAINT road_segments_pkey PRIMARY KEY (id);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: region_uk; Owner: -
--

ALTER TABLE ONLY region_uk.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: road_segments road_segments_pkey; Type: CONSTRAINT; Schema: region_uk; Owner: -
--

ALTER TABLE ONLY region_uk.road_segments
    ADD CONSTRAINT road_segments_pkey PRIMARY KEY (id);


--
-- Name: idx_analytics_events_type_created; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX idx_analytics_events_type_created ON analytics.booking_events USING btree (event_type, created_at DESC);


--
-- Name: idx_auth_users_plate_number; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_users_plate_number ON auth.users USING btree (plate_number);


--
-- Name: idx_bookings_driver_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_driver_created ON public.bookings USING btree (driver_id, created_at DESC);


--
-- Name: idx_bookings_plate_status_departure; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_plate_status_departure ON public.bookings USING btree (plate_number, status, departure_time DESC);


--
-- Name: idx_notifications_user_sent_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_sent_at ON public.notifications USING btree (user_id, sent_at DESC);


--
-- Name: idx_segment_reservations_booking_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_segment_reservations_booking_status ON public.segment_reservations USING btree (booking_id, status);


--
-- Name: segment_reservations segment_reservations_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.segment_reservations
    ADD CONSTRAINT segment_reservations_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id);


--
-- Name: reservations reservations_segment_id_fkey; Type: FK CONSTRAINT; Schema: region_france; Owner: -
--

ALTER TABLE ONLY region_france.reservations
    ADD CONSTRAINT reservations_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES region_france.road_segments(id);


--
-- Name: reservations reservations_segment_id_fkey; Type: FK CONSTRAINT; Schema: region_ireland; Owner: -
--

ALTER TABLE ONLY region_ireland.reservations
    ADD CONSTRAINT reservations_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES region_ireland.road_segments(id);


--
-- Name: reservations reservations_segment_id_fkey; Type: FK CONSTRAINT; Schema: region_uk; Owner: -
--

ALTER TABLE ONLY region_uk.reservations
    ADD CONSTRAINT reservations_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES region_uk.road_segments(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 30TmP1E9fMXhd0jYPGknNEyhKmidskyaHLB74l3PRXkhcenIBYfyrgQNeAL9llF

